#pragma once
void print_values(HashTable *hash, BinaryTree *tree);
